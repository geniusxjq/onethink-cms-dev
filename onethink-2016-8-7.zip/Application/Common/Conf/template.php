<?php
return array(
			 
    /* ģ��������� */
    'TMPL_PARSE_STRING' => array(
		 '__PUBLIC__' => __ROOT__ . '/Public', 
        '__STATIC__' => __ROOT__ . '/Public/static',
    ),
	
);