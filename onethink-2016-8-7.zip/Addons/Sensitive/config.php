<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013 http://www.onethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: yangweijie <yangweijiester@gmail.com> <code-tech.diandian.com>
// +----------------------------------------------------------------------

return array(

	'is_open'=>array(
		'title'=>'是否开启敏感词过滤:',
		'type'=>'radio',
		'options'=>array(
			'1'=>'开启',
			'0'=>'关闭'
		),
		'value'=>'1'
	)
);
