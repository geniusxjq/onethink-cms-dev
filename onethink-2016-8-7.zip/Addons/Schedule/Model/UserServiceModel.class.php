<?php

namespace Addons\Schedule\Model;

/**
 * 用户服务
 * by iszhang
 */
class UserServiceModel{
	
	/**
	 * 用常规方式发送邮件。
	 */
	function send_mail($to = '', $subject = '', $body = '', $name = '', $attachment = null)
	{
		send_mail($to , $subject, $body , $name, $attachment );
	}

}
