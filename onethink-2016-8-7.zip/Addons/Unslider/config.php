<?php
return array(
	'title'=>array(
		'title'=>'显示标题:',
		'type'=>'text',
		'value'=>'Uslider',
	),
	'display'=>array(
		'title'=>'是否显示:',
		'type'=>'radio',
		'options'=>array(
			'1'=>'显示',
			'0'=>'不显示'
		),
		'value'=>'1'
	)
);
