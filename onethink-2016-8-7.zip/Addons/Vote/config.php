<?php
return array(
	'defaultid'=>array(
		'title'=>'默认显示投票（ID）:',
		'type'=>'text',
		'value'=>'0',
	),
	'display'=>array(
		'title'=>'是否开启投票:',
		'type'=>'radio',
		'options'=>array(
			'1'=>'开启',
			'0'=>'关闭',
		),
		'value'=>'1',
	),
);
					